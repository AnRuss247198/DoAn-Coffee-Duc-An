package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.HoaDonMangVe;

public interface ItemHoaDonMangVeOnClick {
    void itemOclick(View view, HoaDonMangVe hoaDonMangVe);

    void itemDuyet(View view, HoaDonMangVe hoaDonMangVe);

    void itemHuy(View view, HoaDonMangVe hoaDonMangVe);
}
