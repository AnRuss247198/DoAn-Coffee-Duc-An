package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.NguoiDung;

public interface ItemNguoiDungOnClick {
    void itemOclick(View view, NguoiDung nguoiDung);
}
