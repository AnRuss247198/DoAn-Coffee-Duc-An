package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.LoaiHang;

public interface ItemLoaiHangOnClick {
    void itemOclick(View view, LoaiHang loaiHang);
}
