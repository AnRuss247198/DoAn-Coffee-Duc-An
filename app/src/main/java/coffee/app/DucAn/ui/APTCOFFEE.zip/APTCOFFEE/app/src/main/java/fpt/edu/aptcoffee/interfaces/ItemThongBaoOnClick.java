package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.Ban;
import fpt.edu.aptcoffee.model.ThongBao;

public interface ItemThongBaoOnClick {
    void itemOclick(View view, ThongBao thongBao);
}
