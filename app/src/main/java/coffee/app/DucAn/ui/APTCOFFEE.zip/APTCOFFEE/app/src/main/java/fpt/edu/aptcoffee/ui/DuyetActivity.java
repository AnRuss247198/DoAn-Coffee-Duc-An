package fpt.edu.aptcoffee.ui;

import static fpt.edu.aptcoffee.model.HoaDonMangVe.CHUA_DUYET;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.Calendar;

import fpt.edu.aptcoffee.R;
import fpt.edu.aptcoffee.adapter.DuyetAdapter;
import fpt.edu.aptcoffee.adapter.HoaDonAdapter;
import fpt.edu.aptcoffee.dao.HoaDonDAO;
import fpt.edu.aptcoffee.dao.HoaDonMangVeDao;
import fpt.edu.aptcoffee.interfaces.ItemHoaDonMangVeOnClick;
import fpt.edu.aptcoffee.interfaces.ItemHoaDonOnClick;
import fpt.edu.aptcoffee.model.HoaDon;
import fpt.edu.aptcoffee.model.HoaDonMangVe;

public class DuyetActivity extends AppCompatActivity{
    public static final String MA_HOA_DON = "maHoaDon";
    Toolbar toolbar;
    RecyclerView recyclerViewHoaDon;
    HoaDonMangVeDao hoaDonDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duyet);
        initToolBar();

        initView();
        hoaDonDAO = new HoaDonMangVeDao(this);
        loadData();
    }


    private void loadData() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        recyclerViewHoaDon.setLayoutManager(linearLayoutManager);
        DuyetAdapter adapter = new DuyetAdapter(hoaDonDAO.getByTrangThai(CHUA_DUYET), DuyetActivity.this, new ItemHoaDonMangVeOnClick() {
            @Override
            public void itemOclick(View view, HoaDonMangVe hoaDonMangVe) {
                Intent intent = new Intent(DuyetActivity.this, ChiTietHoaDonMangVeActivity.class);
                intent.putExtra(MA_HOA_DON, String.valueOf(hoaDonMangVe.getMaHoaDon()));
                startActivity(intent);
                overridePendingTransition(R.anim.anim_in_right, R.anim.anim_out_left);
            }

            @Override
            public void itemDuyet(View view, HoaDonMangVe hoaDonMangVe) {
                Calendar c = Calendar.getInstance();
                hoaDonMangVe.setTrangThai(HoaDonMangVe.DA_DUYET);
                hoaDonMangVe.setGioRa(c.getTime());
                HoaDonMangVeDao hoaDonMangVeDao = new HoaDonMangVeDao(DuyetActivity.this);
                hoaDonMangVeDao.updateHoaDonMangVe(hoaDonMangVe);
                loadData();
            }
            @Override
            public void itemHuy(View view, HoaDonMangVe hoaDonMangVe) {
                hoaDonMangVe.setTrangThai(HoaDonMangVe.HUY_HOA_DON);
                hoaDonDAO.updateHoaDonMangVe(hoaDonMangVe);
                loadData();
            }
        });
        recyclerViewHoaDon.setAdapter(adapter);
    }

    private void initView() {
        recyclerViewHoaDon = findViewById(R.id.recyclerViewHoaDon);
    }

    private void initToolBar() {
        toolbar = findViewById(R.id.toolbarHoaDon);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.anim_in_left, R.anim.anim_out_right);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

}