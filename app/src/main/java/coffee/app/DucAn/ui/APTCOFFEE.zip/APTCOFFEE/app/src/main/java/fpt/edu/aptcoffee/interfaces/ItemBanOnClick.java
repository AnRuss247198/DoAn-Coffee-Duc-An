package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.Ban;
import fpt.edu.aptcoffee.model.HangHoa;

public interface ItemBanOnClick {
    void itemOclick(View view, Ban ban);
}
