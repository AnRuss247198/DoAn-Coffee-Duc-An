package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.Ban;
import fpt.edu.aptcoffee.model.HangHoa;

public interface ItemOderOnClick {
    void itemOclick(View view, HangHoa hangHoa);
}
