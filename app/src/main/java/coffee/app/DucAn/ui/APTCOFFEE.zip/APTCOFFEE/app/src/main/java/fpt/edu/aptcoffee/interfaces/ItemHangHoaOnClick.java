package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.HangHoa;
import fpt.edu.aptcoffee.model.NguoiDung;

public interface ItemHangHoaOnClick {
    void itemOclick(View view, HangHoa hangHoa);
}
