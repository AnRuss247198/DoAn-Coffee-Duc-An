package fpt.edu.aptcoffee.interfaces;

import android.view.View;

import fpt.edu.aptcoffee.model.HangHoa;
import fpt.edu.aptcoffee.model.HoaDon;

public interface ItemHoaDonOnClick {
    void itemOclick(View view, HoaDon hoaDon);
}
