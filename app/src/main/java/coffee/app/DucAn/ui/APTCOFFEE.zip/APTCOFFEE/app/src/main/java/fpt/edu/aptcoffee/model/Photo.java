package fpt.edu.aptcoffee.model;

public class Photo {
    private int srcImage;

    public int getSrcImage() {
        return srcImage;
    }

    public void setSrcImage(int srcImage) {
        this.srcImage = srcImage;
    }

    public Photo(int srcImage) {
        this.srcImage = srcImage;
    }
}
