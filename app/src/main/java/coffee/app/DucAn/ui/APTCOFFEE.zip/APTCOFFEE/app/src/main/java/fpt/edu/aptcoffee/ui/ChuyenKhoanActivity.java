package fpt.edu.aptcoffee.ui;

import static fpt.edu.aptcoffee.ui.OderActivity.maBan;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Calendar;

import fpt.edu.aptcoffee.MainActivity;
import fpt.edu.aptcoffee.R;
import fpt.edu.aptcoffee.dao.BanDAO;
import fpt.edu.aptcoffee.dao.HoaDonChiTietDAO;
import fpt.edu.aptcoffee.dao.HoaDonDAO;
import fpt.edu.aptcoffee.dao.HoaDonMangVeDao;
import fpt.edu.aptcoffee.dao.ThongBaoDAO;
import fpt.edu.aptcoffee.model.Ban;
import fpt.edu.aptcoffee.model.HoaDon;
import fpt.edu.aptcoffee.model.HoaDonMangVe;
import fpt.edu.aptcoffee.model.ThongBao;
import fpt.edu.aptcoffee.notification.MyNotification;
import fpt.edu.aptcoffee.utils.MyToast;

public class ChuyenKhoanActivity extends AppCompatActivity {
    TextView tvctieptuc,tvchuyenkhoan;
    HoaDonDAO hoaDonDAO;
    HoaDonChiTietDAO hoaDonChiTietDAO;
    BanDAO banDAO;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_chuyenkhoan);

        tvctieptuc = findViewById(R.id.tvctieptuc);
        tvchuyenkhoan = findViewById(R.id.tvchuyenkhoan);

        hoaDonDAO = new HoaDonDAO(this);
        hoaDonChiTietDAO = new HoaDonChiTietDAO(this);
        banDAO = new BanDAO(this);
        HoaDon hoaDon = (HoaDon) getIntent().getSerializableExtra("hoaDon");
        Ban ban = (Ban) getIntent().getSerializableExtra("ban");
        if(ban == null || hoaDon == null){
            HoaDonMangVe hoaDonMangVe = (HoaDonMangVe) getIntent().getSerializableExtra("hoaDonMangVe");
            HoaDonMangVeDao hoaDonMangVeDao = new HoaDonMangVeDao(this);
            assert hoaDonMangVe != null;
            tvchuyenkhoan.setText(hoaDonMangVeDao.getGiaTien(hoaDonMangVe.getMaHoaDon())+"");
            tvctieptuc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    hoaDonMangVeDao.updateHoaDonMangVe(hoaDonMangVe);
                    onBackPressed();
                }
            });
        }else {
            assert hoaDon != null;
            tvchuyenkhoan.setText(hoaDonChiTietDAO.getGiaTien(hoaDon.getMaHoaDon()) + "");

            tvctieptuc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Calendar calendar = Calendar.getInstance();
                    if (banDAO.updateBan(ban) && hoaDonDAO.updateHoaDon(hoaDon)) {
                        MyToast.successful(ChuyenKhoanActivity.this, "Thanh Toán thành công");
                        MyNotification.getNotification(ChuyenKhoanActivity.this, "Thanh toán thành công hoá đơn HD0775098507" + hoaDon.getMaHoaDon());
                        themThonBaoMoi(hoaDon, calendar);
                    }
                    Intent intent = new Intent(ChuyenKhoanActivity.this, QuanLyBanActivity.class);
                    maBan = "";
                    startActivity(intent);
                    finish();
                }
            });
        }
    }

    private void themThonBaoMoi(HoaDon hoaDon, Calendar calendar) {
        // Tạo thông báo thanh toán hoá đơn
        ThongBao thongBao = new ThongBao();
        thongBao.setNoiDung("Thanh toán thành công hoá đơn HD0775098507"+ hoaDon.getMaHoaDon());
        thongBao.setTrangThai(ThongBao.STATUS_CHUA_XEM);
        thongBao.setNgayThongBao(calendar.getTime());
        ThongBaoDAO thongBaoDAO = new ThongBaoDAO(ChuyenKhoanActivity.this);
        thongBaoDAO.insertThongBao(thongBao);
    }
}